### documented by Timur Pratama Wiradarma
===================================
Official Duitku OpenCart Extension
===================================

Duitku OpenCart!

This is the official Duitku extension for the OpenCart E-commerce platform.

## Installation

1. Extract '.zip' file dari duitku opencart

2. Copy `admin`, `catalog`, and `system` folders into your _OpenCart's_ root folder.

3. In your _OpenCart_ admin page, go to payment module under extension's menu.

4. Enable Duitku payment gateway (e.g., Duitku BCA, Duitku Credit Card, etc) and
   required fields (Merchant code, Apikey, endpoints and Display name)

5. In order to get the required fields please contact duitku admin : admin@duitku.com

