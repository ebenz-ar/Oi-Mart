1.0
-----
- Supporting connection to BCA, Credit Card, Mandiri, Bank Transfer, Cimb and Duitku Wallet

1.1
-----
- add channels to ATM Bersama, BNI, CIMB and Maybank

1.2
-----
- add channels to OVO

1.3
-----
- add channels to Mandiri Virtual Account


2.0
-----
- Upgrade Duitku API V2
- add channels to ShopeePay
- add channels to Indodana

2.1
-----
- Improve parameter Duitku Expiry Period

2.2
-----
- add channels to BCA Virtual Account

2.3
-----
- Update channel Mandiri Virtual Account become Deprecated
- add channels to VA Mandiri Direct

2.4
-----
- Update channel Dana
- Update channel LinkAja Fixed and Percentage

2.9
-----
- add channel PosPay

2.10
-----
- add channel Bank Neo Commerce
- remove Deprecated Mandiri

2.11
----
- add channel Briva
- add channel QRIS by Nobu